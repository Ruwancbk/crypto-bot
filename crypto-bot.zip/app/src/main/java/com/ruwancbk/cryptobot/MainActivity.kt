package com.ruwancbk.cryptobot

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.webkit.JavascriptInterface
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.LinearLayout

/** Thin shell around the bot dashboard served by your server. Stores server URL + token on the device. */
class MainActivity : Activity() {

    private lateinit var web: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#6C3CE0")

        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(), "Android")
        web.webViewClient = object : WebViewClient() {
            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                if (request.isForMainFrame) {
                    view.loadData(
                        "<body style='font-family:sans-serif;padding:24px'><h3>Server එකට සම්බන්ධ වෙන්න බැහැ</h3>" +
                            "<p>Server එක දුවනවාද, URL එක නිවැරදිද බලන්න.</p></body>",
                        "text/html; charset=utf-8", "UTF-8"
                    )
                }
            }
        }

        if (savedUrl().isEmpty()) showSetup() else loadDashboard()
    }

    private fun prefs() = getSharedPreferences("cfg", MODE_PRIVATE)
    private fun savedUrl() = prefs().getString("url", "") ?: ""
    private fun savedToken() = prefs().getString("token", "") ?: ""

    private fun loadDashboard() {
        var url = savedUrl().trim().trimEnd('/')
        if (!url.startsWith("http")) url = "http://$url"
        web.loadUrl("$url/?token=" + java.net.URLEncoder.encode(savedToken(), "UTF-8"))
    }

    private fun showSetup() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 24, 48, 0)
        }
        val url = EditText(this).apply {
            hint = "Server URL (e.g. http://192.168.1.10:8080)"
            setText(savedUrl())
            inputType = InputType.TYPE_TEXT_VARIATION_URI
        }
        val token = EditText(this).apply {
            hint = "Access token"
            setText(savedToken())
        }
        box.addView(url)
        box.addView(token)
        AlertDialog.Builder(this)
            .setTitle("Bot server")
            .setView(box)
            .setCancelable(savedUrl().isNotEmpty())
            .setPositiveButton("Save") { _, _ ->
                prefs().edit()
                    .putString("url", url.text.toString().trim())
                    .putString("token", token.text.toString().trim())
                    .apply()
                loadDashboard()
            }
            .show()
    }

    inner class Bridge {
        @JavascriptInterface
        fun openSetup() {
            runOnUiThread { showSetup() }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
