# Crypto Bot (Binance) — Server + Android App

**⚠️ අවවාදය:** කිසිම bot එකක් ලාභය ගැරන්ටි කරන්නේ නැහැ. මුලින්ම SIGNALS ONLY → PAPER → Binance TESTNET → අන්තිමට පොඩි සැබෑ මුදලකින්.
ඔබට අහිමි වුණාට කමක් නැති මුදලකින් පමණක් පාවිච්චි කරන්න.

## ව්‍යුහය
```
server/   Python bot + dashboard (strategies 22ක්, backtest, signals, paper/live trading)
app/      Android app (dashboard එක phone එකේ පෙන්නන shell එක)
.github/workflows/build-apk.yml   APK එක auto build කරන GitHub Actions
```

## 1) GitHub එකෙන් APK එක හදමු
1. https://github.com/new → repo නම `crypto-bot` (Private).
2. මේ zip එක extract කරලා **ඇතුළේ තියෙන ෆයිල් ටික** repo එකට upload කරන්න (Add file → Upload files). `.github` folder එකත් ඇතුළත් වෙන්න ඕනේ.
3. https://github.com/ruwancbk/crypto-bot/actions → "Build APK" run එක අවසන් වෙනකම් (≈5 min) ඉන්න.
4. APK download: https://github.com/ruwancbk/crypto-bot/releases/download/latest-build/app-debug.apk
5. Phone එකේ install කරන්න ("Install unknown apps" allow කරන්න).

Build fail වුණොත් Actions → ඒ run → log එක මට එවන්න.

## 2) Server එක දුවවමු (PC / VPS / Docker)
```
cd server
pip install -r requirements.txt
python server.py            # ACCESS TOKEN එක print වෙනවා
```
Docker: `docker build -t cryptobot server && docker run -d -p 8080:8080 -v $PWD/state:/app/state cryptobot`

පළමුවෙන් `DEMO=1 python server.py` දුවලා පරීක්ෂා කරන්න (internet/Binance ඕනේ නැහැ).

## 3) App එක connect කරන්න
App එක open කරලා: Server URL (`http://<server-ip>:8080`) + Access token දාන්න.
Home tab → "Strategies" → **Validate now** (පළමු වතාවට විනාඩි කිහිපයක්) → Home → **Start bot**.

## Safety defaults
- Auto trade OFF (signals පමණක්). Settings වලින් ON කරන්න පුළුවන්.
- Paper mode default. Live mode lock වෙලා: server එකේ `LIVE_TRADING=YES` + Binance API keys ඕනේ.
- Binance API key: **Trade permission පමණක්, Withdraw නැහැ, IP whitelist**. `BINANCE_TESTNET=1` වලින් මුලින් testnet.
- Risk %, max positions, daily loss limit settings තියෙනවා.
- Server එක internet එකට විවෘත කරනවා නම් HTTPS (Caddy/Nginx) හෝ Tailscale පාවිච්චි කරන්න.
- Stop-loss/TP bot software එකෙන් බලනවා (තත්පර 15 වරක්). Server නැවතුණොත් open position වලට SL නැහැ.

## Telegram alerts (optional)
`TELEGRAM_TOKEN`, `TELEGRAM_CHAT_ID` env සකසන්න.

## Termux (phone එකේම server)
`pkg install python` → pandas/numpy install අමාරු විය හැක. VPS වඩා විශ්වසනීයයි.
