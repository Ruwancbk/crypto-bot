import numpy as np
import config

def simulate(o, h, l, c, atr, sig, rr, slm, start, end):
    """Signal on candle i close -> enter candle i+1 open. SL/TP from ATR. SL wins if both hit in one candle."""
    n = len(c); trades = []; busy = -1
    for i in np.flatnonzero(sig[start:end]) + start:
        if i <= busy or i + 1 >= n: continue
        d = int(sig[i]); e = i + 1
        entry = o[e] * (1 + d * config.SLIP)
        risk = slm * atr[i]
        if risk / entry < 0.003: continue          # stop too tight vs fees/noise
        sl = entry - d * risk; tp = entry + d * rr * risk
        jend = min(e + config.MAX_HOLD, n - 1); xp = None
        for j in range(e, jend + 1):
            hit_sl = l[j] <= sl if d == 1 else h[j] >= sl
            hit_tp = h[j] >= tp if d == 1 else l[j] <= tp
            if hit_sl: xp = sl * (1 - d * config.SLIP); break
            if hit_tp: xp = tp; break
        if xp is None: xp = c[jend]; j = jend
        pnl = d * (xp - entry) / entry - 2 * config.FEE
        trades.append((i, j, pnl, pnl / (risk / entry)))
        busy = j
    return trades

def stats(trades):
    if not trades: return dict(n=0, wr=0, exp=0, pf=0, dd=0, total=0)
    r = np.array([t[3] for t in trades]); pos = r[r > 0].sum(); neg = -r[r < 0].sum()
    cum = np.cumsum(r); dd = (np.maximum.accumulate(cum) - cum).max()
    return dict(n=len(r), wr=(r > 0).mean(), exp=r.mean(), pf=pos / neg if neg > 0 else 99.0, dd=dd, total=r.sum())
