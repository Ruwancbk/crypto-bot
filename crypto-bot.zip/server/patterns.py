"""Candlestick + chart patterns. Pivots are only 'known' k bars after they form (no look-ahead)."""
import numpy as np, pandas as pd

def get_pivots(df, k=5):
    key = ("piv", k)
    if key in df.attrs: return df.attrs[key]
    hi, lo, w, n = df["high"], df["low"], 2*k+1, len(df)
    ph = np.where(hi.values == hi.rolling(w, center=True).max().values)[0]
    pl = np.where(lo.values == lo.rolling(w, center=True).min().values)[0]
    highs = [(int(i), float(hi.values[i]), int(i+k)) for i in ph if k <= i < n-k]
    lows = [(int(i), float(lo.values[i]), int(i+k)) for i in pl if k <= i < n-k]
    df.attrs[key] = (highs, lows)
    return highs, lows

def candles(df):
    o, h, l, c = df["open"], df["high"], df["low"], df["close"]
    body = (c-o).abs(); rng = (h-l).replace(0, np.nan)
    upper = h - np.maximum(o, c); lower = np.minimum(o, c) - l
    big = body > body.rolling(20).mean()
    d = {}
    d["bull_engulf"] = (c > o) & (c.shift() < o.shift()) & (c >= o.shift()) & (o <= c.shift()) & big
    d["bear_engulf"] = (c < o) & (c.shift() > o.shift()) & (c <= o.shift()) & (o >= c.shift()) & big
    d["hammer"] = (lower > 2*body) & (upper < body) & (body/rng < 0.4)
    d["shooting"] = (upper > 2*body) & (lower < body) & (body/rng < 0.4)
    mid = (o.shift(2) + c.shift(2)) / 2
    small1 = body.shift() < body.shift(2) * 0.5
    d["morning_star"] = (c.shift(2) < o.shift(2)) & small1 & (c > o) & (c > mid)
    d["evening_star"] = (c.shift(2) > o.shift(2)) & small1 & (c < o) & (c < mid)
    d["inside_bar"] = (h < h.shift()) & (l > l.shift())
    return d

# ---------- chart patterns (written for LONG; shorts via mirrored prices) ----------
def _flip(df):
    return pd.DataFrame({"open": -df["open"], "high": -df["low"], "low": -df["high"],
                         "close": -df["close"], "volume": df["volume"]}, index=df.index)

def _fire(sig, c, t, level, expiry=20):
    for j in range(t, min(t+expiry, len(c))):
        if c[j] > level:
            sig[j] = 1; return

def _double_bottom(df):
    highs, lows = get_pivots(df); c, hi = df["close"].values, df["high"].values
    sig = np.zeros(len(df))
    for a in range(1, len(lows)):
        i1, p1, _ = lows[a-1]; i2, p2, t = lows[a]
        if not 8 <= i2-i1 <= 80 or abs(p2-p1)/abs(p1) > 0.015: continue
        neck = hi[i1:i2+1].max()
        if (neck - max(p1, p2)) / abs(p1) < 0.02: continue
        _fire(sig, c, t, neck)
    return sig

def _inv_hns(df):
    highs, lows = get_pivots(df); c, hi = df["close"].values, df["high"].values
    sig = np.zeros(len(df))
    for a in range(2, len(lows)):
        (i1, p1, _), (i2, p2, _), (i3, p3, t) = lows[a-2], lows[a-1], lows[a]
        if not (p2 < p1 and p2 < p3) or abs(p3-p1)/abs(p1) > 0.03: continue
        if not (6 <= i2-i1 <= 60 and 6 <= i3-i2 <= 60): continue
        neck = (hi[i1:i2+1].max() + hi[i2:i3+1].max()) / 2
        if (neck - p2) / abs(p2) < 0.02: continue
        _fire(sig, c, t, neck, 25)
    return sig

def _asc_triangle(df):
    highs, lows = get_pivots(df); c = df["close"].values
    sig = np.zeros(len(df))
    for b in range(1, len(highs)):
        ip, pp, _ = highs[b-1]; ic, pc, t = highs[b]
        if not 8 <= ic-ip <= 60 or abs(pc-pp)/abs(pp) > 0.008: continue
        ls = [x for x in lows if ip-30 <= x[0] <= ic][-2:]
        if len(ls) < 2 or (ls[1][1] - ls[0][1]) / abs(ls[0][1]) < 0.005: continue
        _fire(sig, c, t, max(pp, pc), 15)
    return sig

def _both(fn, df):
    return pd.Series(fn(df) - fn(_flip(df)), index=df.index)

def double_bottom_top(df): return _both(_double_bottom, df)
def inv_head_shoulders(df): return _both(_inv_hns, df)
def triangle_breakout(df): return _both(_asc_triangle, df)
