# ---- General ----
TIMEFRAME = "15m"        # short-term entries
HTF = "1h"               # higher-timeframe trend filter
YEARS = 2                # history to download
LONG_ONLY = True         # Binance SPOT cannot short. Set False only for futures later.

# ---- Costs (Binance spot: 0.1% per side; lower with BNB) ----
FEE = 0.001
SLIP = 0.0005            # extra slippage per market order (small coins: be pessimistic)

# ---- Coin filter (small / mid caps) ----
MIN_QUOTE_VOL = 3_000_000      # 24h USDT volume
MAX_QUOTE_VOL = 300_000_000    # exclude the biggest coins (set high to include BTC/ETH)
MAX_SPREAD = 0.0015            # 0.15%
MIN_BARS = 30000               # need enough history to backtest
STABLES = {"USDC", "FDUSD", "TUSD", "USDP", "DAI", "EUR", "USDE", "XUSD", "AEUR"}

# ---- Backtest / validation ----
TRAIN_FRAC = 0.6               # first 60% = pick parameters, last 40% = untouched test
RR_GRID = [1.5, 2.0, 3.0]      # take-profit = RR x risk
SL_GRID = [1.0, 1.5, 2.0]      # stop-loss = N x ATR
MAX_HOLD = 96                  # bars (24h on 15m)
WARMUP = 250

# A strategy is "validated" only if it passes ALL of these on the TEST period
MIN_TEST_TRADES = 15
MIN_TEST_PF = 1.3
MIN_TEST_EXP = 0.10            # average R per trade after fees
MIN_TRAIN_PF = 1.0
