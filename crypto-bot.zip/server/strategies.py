"""Strategy library. Each function returns a Series: 1 = long signal, -1 = short signal, 0 = none,
evaluated on the CLOSE of a candle (entry happens on the next candle's open)."""
import numpy as np, pandas as pd
from indicators import *
from patterns import get_pivots, candles, double_bottom_top, inv_head_shoulders, triangle_breakout

STRATEGIES = {}
def strat(f): STRATEGIES[f.__name__] = f; return f
def _x(a, b): return (a > b) & (a.shift() <= b.shift())
def _s(long, short): return pd.Series(np.where(long, 1, np.where(short, -1, 0)), index=long.index)

# ---------------- Trend ----------------
@strat
def ema_cross_9_21(df):
    a, b = ema(df.close, 9), ema(df.close, 21); return _s(_x(a, b), _x(b, a))

@strat
def triple_ema_trend(df):
    a, b, c = ema(df.close, 8), ema(df.close, 21), ema(df.close, 55)
    up = (a > b) & (b > c); dn = (a < b) & (b < c)
    return _s(up & ~up.shift(fill_value=False), dn & ~dn.shift(fill_value=False))

@strat
def ema_pullback_trend(df):
    e21, e50, e200 = ema(df.close, 21), ema(df.close, 50), ema(df.close, 200)
    lg = (df.close > e50) & (e50 > e200) & (df.low <= e21) & (df.close > e21) & (df.close > df.open)
    sh = (df.close < e50) & (e50 < e200) & (df.high >= e21) & (df.close < e21) & (df.close < df.open)
    return _s(lg, sh)

@strat
def supertrend_flip(df):
    d = supertrend(df); return _s((d == 1) & (d.shift() == -1), (d == -1) & (d.shift() == 1))

@strat
def adx_di_cross(df):
    a, p, m = adx(df); return _s(_x(p, m) & (a > 25), _x(m, p) & (a > 25))

@strat
def macd_cross(df):
    m, s, _ = macd(df.close); return _s(_x(m, s) & (m < 0), _x(s, m) & (m > 0))

# ---------------- Mean reversion ----------------
@strat
def rsi_reversal_trend(df):
    r = rsi(df.close); e = ema(df.close, 50)
    return _s((r.shift() < 30) & (r >= 30) & (df.close > e * 0.97), (r.shift() > 70) & (r <= 70) & (df.close < e * 1.03))

@strat
def bollinger_bounce(df):
    m, u, l = bollinger(df.close); r = rsi(df.close)
    return _s((df.low < l) & (df.close > l) & (r < 40), (df.high > u) & (df.close < u) & (r > 60))

@strat
def stoch_cross(df):
    k, d = stoch(df); return _s(_x(k, d) & (k < 25), _x(d, k) & (k > 75))

@strat
def vwap_reversion(df):
    v = rolling_vwap(df); z = (df.close - v) / df.close.rolling(96).std()
    return _s((z.shift() < -2) & (z >= -2), (z.shift() > 2) & (z <= 2))

@strat
def rsi_divergence(df):
    highs, lows = get_pivots(df); r = rsi(df.close).values; sig = np.zeros(len(df))
    for a in range(1, len(lows)):
        (i1, p1, _), (i2, p2, t) = lows[a-1], lows[a]
        if 5 <= i2-i1 <= 60 and p2 < p1 and r[i2] > r[i1] and r[i1] < 40: sig[t] = 1
    for a in range(1, len(highs)):
        (i1, p1, _), (i2, p2, t) = highs[a-1], highs[a]
        if 5 <= i2-i1 <= 60 and p2 > p1 and r[i2] < r[i1] and r[i1] > 60: sig[t] = -1
    return pd.Series(sig, index=df.index)

# ---------------- Breakout / volatility ----------------
@strat
def donchian_breakout_20(df):
    return _s(df.close > df.high.rolling(20).max().shift(), df.close < df.low.rolling(20).min().shift())

@strat
def bollinger_squeeze_breakout(df):
    m, u, l = bollinger(df.close); bw = (u - l) / m
    sq = bw.shift() <= bw.rolling(100).quantile(0.2).shift()
    return _s(sq & (df.close > u.shift()), sq & (df.close < l.shift()))

@strat
def volume_spike_breakout(df):
    vs = df.volume > 3 * df.volume.rolling(20).mean()
    return _s(vs & (df.close > df.high.rolling(10).max().shift()) & (df.close > df.open),
              vs & (df.close < df.low.rolling(10).min().shift()) & (df.close < df.open))

@strat
def inside_bar_breakout(df):
    ib = candles(df)["inside_bar"].shift(); mh, ml = df.high.shift(2), df.low.shift(2)
    return _s(ib & (df.close > mh), ib & (df.close < ml))

# ---------------- Support / resistance / liquidity ----------------
@strat
def sr_bounce(df):
    highs, lows = get_pivots(df); n = len(df)
    sup = np.full(n, np.nan); res = np.full(n, np.nan)
    for _, p, t in lows: sup[t] = p
    for _, p, t in highs: res[t] = p
    sup = pd.Series(sup, index=df.index).ffill(); res = pd.Series(res, index=df.index).ffill()
    return _s((df.low <= sup*1.003) & (df.close > sup) & (df.close > df.open),
              (df.high >= res*0.997) & (df.close < res) & (df.close < df.open))

@strat
def liquidity_sweep(df):
    pl = df.low.rolling(20).min().shift(); ph = df.high.rolling(20).max().shift()
    return _s((df.low < pl) & (df.close > pl) & (df.close > df.open),
              (df.high > ph) & (df.close < ph) & (df.close < df.open))

# ---------------- Candlestick (with context) ----------------
@strat
def engulfing_trend(df):
    c = candles(df); e = ema(df.close, 50)
    return _s(c["bull_engulf"] & (df.close > e), c["bear_engulf"] & (df.close < e))

@strat
def pin_bar_extreme(df):
    c = candles(df); r = rsi(df.close)
    return _s(c["hammer"] & (r < 40), c["shooting"] & (r > 60))

@strat
def star_reversal(df):
    c = candles(df); return _s(c["morning_star"], c["evening_star"])

# ---------------- Chart patterns ----------------
@strat
def double_bottom_top_break(df): return double_bottom_top(df)
@strat
def inv_head_shoulders_break(df): return inv_head_shoulders(df)
@strat
def triangle_break(df): return triangle_breakout(df)
