import os
import numpy as np, pandas as pd
import config

def _ex():
    import ccxt
    return ccxt.binance({"enableRateLimit": True})

def _tf_ms(tf): return int(tf[:-1]) * {"m": 60_000, "h": 3_600_000, "d": 86_400_000}[tf[-1]]

def load_ohlcv(symbol, tf=config.TIMEFRAME, years=config.YEARS):
    """Public Binance data (no API key needed). Cached in ./data. Unclosed candle is dropped."""
    os.makedirs("data", exist_ok=True)
    path = f"data/{symbol.replace('/', '_')}_{tf}.csv"
    ex = _ex(); step = _tf_ms(tf); now = ex.milliseconds(); old = None
    if os.path.exists(path):
        old = pd.read_csv(path, index_col=0, parse_dates=True)
        since = int(old.index[-1].timestamp() * 1000) + step
    else:
        since = now - int(years * 365 * 86400 * 1000)
    rows = []
    while since < now:
        b = ex.fetch_ohlcv(symbol, tf, since=since, limit=1000)
        if not b: break
        rows += b; since = b[-1][0] + step
    if rows:
        rows = rows[:-1] if rows[-1][0] + step > now else rows   # drop forming candle
        new = pd.DataFrame(rows, columns=["ts", "open", "high", "low", "close", "volume"])
        new.index = pd.to_datetime(new.pop("ts"), unit="ms", utc=True)
        df = pd.concat([old, new]) if old is not None else new
    else:
        df = old
    df = df[~df.index.duplicated()].sort_index()
    df = df[df.index >= df.index[-1] - pd.Timedelta(days=365 * years)]
    df.to_csv(path)
    return df

def pick_symbols(limit=30):
    ex = _ex(); ex.load_markets(); t = ex.fetch_tickers(); out = []
    for sym, x in t.items():
        m = ex.markets.get(sym)
        if not m or not m.get("spot") or not sym.endswith("/USDT") or not m.get("active", True): continue
        if m["base"] in config.STABLES: continue
        qv = x.get("quoteVolume") or 0
        if not config.MIN_QUOTE_VOL <= qv <= config.MAX_QUOTE_VOL: continue
        bid, ask = x.get("bid"), x.get("ask")
        if not bid or not ask or (ask - bid) / ask > config.MAX_SPREAD: continue
        out.append((sym, qv))
    out.sort(key=lambda z: -z[1])
    return [s for s, _ in out[:limit]]

def synthetic(n=60000, seed=1):
    """Random-walk data for testing the code without internet."""
    rng = np.random.default_rng(seed); k = np.arange(n)
    vol = 0.0025 * (1 + 0.5 * np.sin(k / 2000))
    close = 100 * np.exp(np.cumsum(rng.normal(0, vol) + 0.00002 * np.sin(k / 5000)))
    op = np.r_[100, close[:-1]]
    hi = np.maximum(op, close) * (1 + np.abs(rng.normal(0, vol / 2)))
    lo = np.minimum(op, close) * (1 - np.abs(rng.normal(0, vol / 2)))
    idx = pd.date_range("2024-01-01", periods=n, freq="15min", tz="UTC")
    return pd.DataFrame({"open": op, "high": hi, "low": lo, "close": close,
                         "volume": rng.lognormal(10, 0.5, n)}, index=idx)
