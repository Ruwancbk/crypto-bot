"""Bot engine: validation job (heavy, daily) + signal check (every closed candle) + trade management.
Default = SIGNALS ONLY. Paper trading is opt-in. Live trading is locked unless LIVE_TRADING=YES + API keys."""
import json, os, threading, time, uuid, datetime as dt
import numpy as np, pandas as pd
import config, notify
from indicators import atr
from scanner import evaluate, htf_trend, _apply_htf
import strategies as S

STATE_FILE = os.environ.get("STATE_FILE", "state.json")
LOCK = threading.RLock()
TF_SEC = int(config.TIMEFRAME[:-1]) * 60
DEFAULTS = dict(mode="paper", auto_trade=False, risk_pct=1.0, max_positions=3, max_daily_loss_pct=3.0,
                paper_balance=1000.0, top_symbols=20, validate_hours=24)

def now(): return dt.datetime.now(dt.timezone.utc)
def iso(t=None): return (t or now()).strftime("%Y-%m-%dT%H:%M:%SZ")
def live_allowed():
    return (os.environ.get("LIVE_TRADING") == "YES" and os.environ.get("BINANCE_API_KEY") and os.environ.get("BINANCE_API_SECRET"))

# ------------------------------------------------------------------ markets
class BinanceMarket:
    def __init__(self):
        import ccxt
        self.pub = ccxt.binance({"enableRateLimit": True})
        key, sec = os.environ.get("BINANCE_API_KEY"), os.environ.get("BINANCE_API_SECRET")
        self.trade = None
        if key and sec:
            self.trade = ccxt.binance({"enableRateLimit": True, "apiKey": key, "secret": sec})
            if os.environ.get("BINANCE_TESTNET") == "1": self.trade.set_sandbox_mode(True)
            self.trade.load_markets()

    def symbols(self, top):
        from data import pick_symbols; return pick_symbols(top)
    def history(self, symbol):
        from data import load_ohlcv; return load_ohlcv(symbol)
    def recent(self, symbol, n=1000):
        rows = self.pub.fetch_ohlcv(symbol, config.TIMEFRAME, limit=n)
        df = pd.DataFrame(rows, columns=["ts", "open", "high", "low", "close", "volume"])
        df.index = pd.to_datetime(df.pop("ts"), unit="ms", utc=True)
        if df.index[-1].timestamp() + TF_SEC > time.time(): df = df.iloc[:-1]   # drop forming candle
        return df
    def price(self, symbol): return float(self.pub.fetch_ticker(symbol)["last"])
    def balance(self): return float(self.trade.fetch_balance()["USDT"]["free"])
    def buy(self, symbol, usdt):
        m = self.trade.market(symbol); mn = (m.get("limits", {}).get("cost", {}) or {}).get("min") or 0
        if usdt < mn: raise ValueError(f"order {usdt:.2f} below minimum {mn}")
        p = self.price(symbol); amt = float(self.trade.amount_to_precision(symbol, usdt / p))
        o = self.trade.create_market_buy_order(symbol, amt)
        return float(o.get("average") or o.get("price") or p), float(o.get("filled") or amt)
    def sell(self, symbol, qty):
        base = self.trade.market(symbol)["base"]
        free = float(self.trade.fetch_balance()[base]["free"])
        amt = float(self.trade.amount_to_precision(symbol, min(qty, free)))
        o = self.trade.create_market_sell_order(symbol, amt)
        return float(o.get("average") or o.get("price") or self.price(symbol))

class DemoMarket:
    """Fake market for testing without internet."""
    def __init__(self): self.px = {}; self.rng = np.random.default_rng(1); self.cache = {}
    def _df(self, s):
        if s not in self.cache:
            from data import synthetic; self.cache[s] = synthetic(40000, seed=sum(map(ord, s)) % 1000)
        return self.cache[s]
    def symbols(self, top): return ["AAA/USDT", "BBB/USDT", "CCC/USDT"][:top]
    def history(self, s): return self._df(s)
    def recent(self, s, n=1000): return self._df(s).iloc[-n:]
    def price(self, s):
        p = self.px.get(s, float(self._df(s)["close"].iloc[-1])) * (1 + self.rng.normal(0, 0.002))
        self.px[s] = p; return p

# ------------------------------------------------------------------ engine
class Engine:
    def __init__(self, market):
        self.market = market; self.seen = set(); self.busy = False; self.progress = ""
        self.st = self._load()

    def _load(self):
        st = {}
        if os.path.exists(STATE_FILE):
            try: st = json.load(open(STATE_FILE))
            except Exception: st = {}
        s = st.setdefault("settings", {})
        for k, v in DEFAULTS.items(): s.setdefault(k, v)
        for k, v in dict(enabled=False, validated=[], validated_at=None, signals=[], positions=[],
                         history=[], log=[], day={}).items(): st.setdefault(k, v)
        st.setdefault("paper_cash", float(s["paper_balance"]))
        if s["mode"] == "live" and not live_allowed(): s["mode"] = "paper"
        return st

    def save(self):
        with LOCK:
            tmp = STATE_FILE + ".tmp"; json.dump(self.st, open(tmp, "w")); os.replace(tmp, STATE_FILE)

    def log(self, msg):
        print(iso(), msg, flush=True)
        with LOCK:
            self.st["log"].insert(0, f"{iso()}  {msg}"); del self.st["log"][100:]

    # ---------------- settings / control
    def update_settings(self, new):
        s = self.st["settings"]
        spec = dict(risk_pct=(0.1, 5.0, float), max_positions=(1, 10, int), max_daily_loss_pct=(0.5, 20.0, float),
                    top_symbols=(3, 60, int), paper_balance=(10, 1e7, float), validate_hours=(6, 168, int))
        for k, (lo, hi, tp) in spec.items():
            if k in new: s[k] = min(hi, max(lo, tp(new[k])))
        if "auto_trade" in new: s["auto_trade"] = bool(new["auto_trade"])
        if "mode" in new and new["mode"] != s["mode"]:
            if new["mode"] not in ("paper", "live"): raise ValueError("bad mode")
            if new["mode"] == "live" and not live_allowed():
                raise ValueError("Live is locked. Server needs LIVE_TRADING=YES and BINANCE_API_KEY/SECRET.")
            if self.st["positions"]: raise ValueError("Close open positions before switching mode")
            s["mode"] = new["mode"]
        self.save()

    def set_enabled(self, on):
        self.st["enabled"] = bool(on); self.log("bot " + ("STARTED" if on else "STOPPED")); self.save()

    def reset_paper(self):
        if self.st["positions"]: raise ValueError("Close open positions first")
        self.st["paper_cash"] = float(self.st["settings"]["paper_balance"]); self.st["history"] = []; self.save()

    # ---------------- validation (heavy)
    def validate(self):
        if self.busy: return
        self.busy = True
        def job():
            try:
                syms = self.market.symbols(self.st["settings"]["top_symbols"]); out = []
                for k, sym in enumerate(syms):
                    self.progress = f"{k+1}/{len(syms)} {sym}"
                    try:
                        df = self.market.history(sym)
                        if len(df) < config.MIN_BARS: continue
                        res = evaluate(df)
                        for r in res[res.validated].itertuples():
                            out.append(dict(symbol=sym, strategy=r.strategy, htf=bool(r.htf), rr=float(r.rr),
                                            sl_atr=float(r.sl_atr), test_pf=float(r.test_pf), test_wr=float(r.test_wr),
                                            test_exp_R=float(r.test_exp_R), test_n=int(r.test_n)))
                    except Exception as e: self.log(f"validate {sym} failed: {e}")
                with LOCK: self.st["validated"] = out; self.st["validated_at"] = iso()
                self.log(f"validation finished: {len(out)} validated strategy/coin pairs"); self.save()
            except Exception as e: self.log(f"validation error: {e}")
            finally: self.busy = False; self.progress = ""
        threading.Thread(target=job, daemon=True).start()

    # ---------------- signals
    def check_signals(self):
        by = {}
        for v in self.st["validated"]: by.setdefault(v["symbol"], []).append(v)
        new = []
        for sym, items in by.items():
            try:
                df = self.market.recent(sym)
                if len(df) < 300: continue
                ts = df.index[-1].strftime("%Y-%m-%dT%H:%M"); a = atr(df).values; up = htf_trend(df)
                for v in items:
                    fn = S.STRATEGIES.get(v["strategy"])
                    if not fn: continue
                    s = np.where(fn(df).values.astype(int) > 0, 1, 0)
                    if v["htf"]: s = _apply_htf(s, up)
                    if s[-1] != 1: continue
                    key = f"{sym}|{v['strategy']}|{ts}"
                    if key in self.seen: continue
                    self.seen.add(key)
                    price = self.market.price(sym); risk = v["sl_atr"] * a[-1]
                    if risk / price < 0.003: continue
                    new.append(dict(id=uuid.uuid4().hex[:8], time=iso(), symbol=sym, side="LONG", strategy=v["strategy"],
                                    entry=price, sl=price - risk, tp=price + v["rr"] * risk,
                                    test_pf=v["test_pf"], test_wr=v["test_wr"]))
            except Exception as e: self.log(f"signal check {sym} failed: {e}")
        if len(self.seen) > 5000: self.seen.clear()
        for sig in new:
            self.st["signals"].insert(0, sig); del self.st["signals"][60:]
            self.log(f"SIGNAL {sig['symbol']} {sig['strategy']} entry {sig['entry']:.6g} SL {sig['sl']:.6g} TP {sig['tp']:.6g}")
            notify.send(f"SIGNAL {sig['symbol']} LONG\nstrategy: {sig['strategy']}\nentry {sig['entry']:.6g}\nSL {sig['sl']:.6g}\nTP {sig['tp']:.6g}\n(test PF {sig['test_pf']}, win {sig['test_wr']}%)")
            if self.st["settings"]["auto_trade"]: self.try_open(sig)
        if new: self.save()

    # ---------------- trading
    def equity(self):
        if self.st["settings"]["mode"] == "live":
            return self.market.balance() + sum(p["notional"] for p in self.st["positions"])
        return float(self.st["paper_cash"])

    def _day(self, eq):
        today = now().strftime("%Y-%m-%d"); d = self.st["day"]
        if d.get("date") != today: d = self.st["day"] = dict(date=today, start=eq, pnl=0.0)
        return d

    def try_open(self, sig):
        s = self.st["settings"]; pos = self.st["positions"]
        if len(pos) >= s["max_positions"] or any(p["symbol"] == sig["symbol"] for p in pos): return
        try:
            eq = self.equity(); d = self._day(eq)
            if d["pnl"] <= -s["max_daily_loss_pct"] / 100 * d["start"]:
                self.log("daily loss limit reached - no new trades today"); return
            per_unit = sig["entry"] - sig["sl"]
            qty = (eq * s["risk_pct"] / 100) / per_unit
            notional = min(qty * sig["entry"], eq / s["max_positions"])
            if notional < 10: self.log("position too small, skipped"); return
            if s["mode"] == "live": fill, qty = self.market.buy(sig["symbol"], notional)
            else: fill = sig["entry"] * (1 + config.SLIP); qty = notional / fill
            shift = fill - sig["entry"]
            p = dict(id=sig["id"], symbol=sig["symbol"], strategy=sig["strategy"], entry=fill, sl=sig["sl"] + shift,
                     tp=sig["tp"] + shift, qty=qty, notional=qty * fill, opened=iso(), mode=s["mode"],
                     expires=iso(now() + dt.timedelta(seconds=config.MAX_HOLD * TF_SEC)))
            pos.append(p); self.save()
            self.log(f"OPEN {p['symbol']} [{p['mode']}] qty {qty:.6g} @ {fill:.6g}")
            notify.send(f"OPENED {p['symbol']} ({p['mode']}) @ {fill:.6g}  SL {p['sl']:.6g}  TP {p['tp']:.6g}")
        except Exception as e: self.log(f"open failed {sig['symbol']}: {e}")

    def close(self, pid, reason="MANUAL"):
        with LOCK:
            p = next((x for x in self.st["positions"] if x["id"] == pid), None)
            if not p: raise ValueError("position not found")
            if p["mode"] == "live": px = self.market.sell(p["symbol"], p["qty"])
            else: px = self.market.price(p["symbol"])
            pnl = (px - p["entry"]) * p["qty"] - 2 * config.FEE * p["notional"]
            if p["mode"] == "paper": self.st["paper_cash"] += pnl
            self.st["positions"].remove(p)
            self._day(self.st["paper_cash"] if p["mode"] == "paper" else 0)["pnl"] += pnl
            self.st["history"].insert(0, dict(symbol=p["symbol"], strategy=p["strategy"], mode=p["mode"], entry=p["entry"],
                                              exit=px, pnl=round(pnl, 4), reason=reason, opened=p["opened"], closed=iso()))
            del self.st["history"][200:]; self.save()
        self.log(f"CLOSE {p['symbol']} {reason} pnl {pnl:+.2f} USDT")
        notify.send(f"CLOSED {p['symbol']} ({reason}) PnL {pnl:+.2f} USDT")

    def monitor(self):
        for p in list(self.st["positions"]):
            try:
                px = self.market.price(p["symbol"]); r = None
                if px <= p["sl"]: r = "SL"
                elif px >= p["tp"]: r = "TP"
                elif iso() >= p["expires"]: r = "TIMEOUT"
                if r: self.close(p["id"], r)
            except Exception as e: self.log(f"monitor {p['symbol']} failed: {e}")

    # ---------------- loop
    def loop(self):
        last_bucket = None; last_mon = 0
        while True:
            try:
                t = time.time()
                if self.st["positions"] and t - last_mon >= 15: self.monitor(); last_mon = t
                if self.st["enabled"]:
                    bucket = int(t // TF_SEC)
                    if bucket != last_bucket and t % TF_SEC >= 20 and self.st["validated"]:
                        last_bucket = bucket; self.check_signals()
                    va = self.st["validated_at"]
                    if not self.busy and (not va or (now() - dt.datetime.strptime(va, "%Y-%m-%dT%H:%M:%SZ").replace(
                            tzinfo=dt.timezone.utc)).total_seconds() > self.st["settings"]["validate_hours"] * 3600):
                        self.validate()
            except Exception as e: self.log(f"loop error: {e}")
            time.sleep(3)

    def start_thread(self): threading.Thread(target=self.loop, daemon=True).start()

    def summary(self):
        s = self.st["settings"]
        try: eq = self.equity()
        except Exception: eq = None
        d = self.st.get("day", {})
        return dict(running=self.st["enabled"], settings=s, live_unlocked=bool(live_allowed()), equity=eq,
                    day_pnl=d.get("pnl", 0.0), validating=self.busy, progress=self.progress,
                    validated_at=self.st["validated_at"], validated=self.st["validated"], positions=self.st["positions"],
                    signals=self.st["signals"][:25], history=self.st["history"][:40], log=self.st["log"][:40])
