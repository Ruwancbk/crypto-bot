"""Usage:
  python main.py demo                      # test the code on fake data (no internet)
  python main.py backtest --symbol DOGE/USDT
  python main.py scan --top 30             # scan small/mid coins on Binance, show live entries
"""
import argparse, os
import pandas as pd
import config
from scanner import evaluate
pd.set_option("display.width", 200); pd.set_option("display.max_columns", 30)

def show(sym, res):
    v = res[res.validated].sort_values("test_exp_R", ascending=False)
    print(f"\n=== {sym}: {len(v)} validated / {len(res)} tested ===")
    if len(v): print(v.drop(columns=["validated", "live_signal", "entry", "sl", "tp"]).to_string(index=False))
    return v

def signals_of(sym, v):
    live = v[v.live_signal != 0]
    return [dict(symbol=sym, side="LONG" if r.live_signal > 0 else "SHORT", strategy=r.strategy,
                 entry=r.entry, sl=r.sl, tp=r.tp, test_pf=r.test_pf, test_wr=r.test_wr) for r in live.itertuples()]

def main():
    p = argparse.ArgumentParser(); p.add_argument("cmd", choices=["demo", "backtest", "scan"])
    p.add_argument("--symbol", default="DOGE/USDT"); p.add_argument("--top", type=int, default=30)
    a = p.parse_args(); allsig = []
    if a.cmd == "demo":
        from data import synthetic
        res = evaluate(synthetic()); allsig += signals_of("DEMO", show("DEMO (random data)", res))
    else:
        from data import load_ohlcv, pick_symbols
        syms = [a.symbol] if a.cmd == "backtest" else pick_symbols(a.top)
        for s in syms:
            try:
                df = load_ohlcv(s)
                if len(df) < config.MIN_BARS: print(f"skip {s}: only {len(df)} bars"); continue
                allsig += signals_of(s, show(s, evaluate(df)))
            except Exception as e: print("error", s, e)
    print("\n##### LIVE SIGNALS (last closed candle) #####")
    if not allsig: print("none right now"); return
    sg = pd.DataFrame(allsig)
    sg["confluence"] = sg.groupby(["symbol", "side"])["strategy"].transform("count")
    sg = sg.sort_values(["confluence", "test_pf"], ascending=False)
    print(sg.to_string(index=False)); os.makedirs("reports", exist_ok=True)
    sg.to_csv("reports/live_signals.csv", index=False)

if __name__ == "__main__": main()
