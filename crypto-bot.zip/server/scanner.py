import numpy as np, pandas as pd
import config
from indicators import atr, ema
from strategies import STRATEGIES
from backtest import simulate, stats

def htf_trend(df):
    h = df["close"].resample(config.HTF, label="left", closed="left").last().dropna()
    up = (h > ema(h, 50)).astype(float).shift(1)          # last COMPLETED higher-tf candle
    return (up.reindex(df.index, method="ffill").fillna(0).values > 0.5)

def _apply_htf(sig, up):
    return np.where(((sig > 0) & up) | ((sig < 0) & ~up), sig, 0)

def evaluate(df, verbose=False):
    n = len(df); split = int(n * config.TRAIN_FRAC)
    o, h, l, c = (df[k].values for k in ("open", "high", "low", "close"))
    a = atr(df).values; up = htf_trend(df); rows = []
    for name, fn in STRATEGIES.items():
        raw = fn(df).values.astype(int)
        if config.LONG_ONLY: raw = np.where(raw > 0, raw, 0)
        best = None
        for use_htf in (False, True):
            s = _apply_htf(raw, up) if use_htf else raw
            for rr in config.RR_GRID:
                for slm in config.SL_GRID:
                    st = stats(simulate(o, h, l, c, a, s, rr, slm, config.WARMUP, split))
                    if st["n"] >= 20 and (best is None or st["exp"] > best[0]["exp"]):
                        best = (st, use_htf, rr, slm, s)
        if best is None: continue
        tr, use_htf, rr, slm, s = best
        te = stats(simulate(o, h, l, c, a, s, rr, slm, split, n))
        ok = (te["n"] >= config.MIN_TEST_TRADES and te["pf"] >= config.MIN_TEST_PF and
              te["exp"] >= config.MIN_TEST_EXP and tr["pf"] >= config.MIN_TRAIN_PF)
        live = int(s[-1]); entry = sl = tp = None
        if live != 0:
            entry = c[-1]; risk = slm * a[-1]; sl = entry - live * risk; tp = entry + live * rr * risk
        rows.append(dict(strategy=name, htf=use_htf, rr=rr, sl_atr=slm, train_n=tr["n"], train_pf=round(tr["pf"], 2),
                         test_n=te["n"], test_wr=round(te["wr"] * 100, 1), test_pf=round(te["pf"], 2),
                         test_exp_R=round(te["exp"], 2), test_maxdd_R=round(te["dd"], 1), validated=ok,
                         live_signal=live, entry=entry, sl=sl, tp=tp))
    return pd.DataFrame(rows)
