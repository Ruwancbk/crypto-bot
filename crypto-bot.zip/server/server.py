"""HTTP server: serves the mobile dashboard + JSON API. Uses only the Python standard library."""
import json, os, secrets, hmac
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse
import bot

def get_token():
    if os.environ.get("APP_TOKEN"): return os.environ["APP_TOKEN"]
    if os.path.exists("token.txt"): return open("token.txt").read().strip()
    t = secrets.token_urlsafe(16); open("token.txt", "w").write(t); return t

TOKEN = get_token()
ENGINE = None
HERE = os.path.dirname(os.path.abspath(__file__))

class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def _send(self, code, body, ctype="application/json"):
        b = body if isinstance(body, bytes) else json.dumps(body).encode()
        self.send_response(code); self.send_header("Content-Type", ctype); self.send_header("Content-Length", str(len(b)))
        self.send_header("Cache-Control", "no-store"); self.end_headers(); self.wfile.write(b)
    def _ok(self): return hmac.compare_digest(self.headers.get("X-Token", ""), TOKEN)

    def do_GET(self):
        path = urlparse(self.path).path
        if path in ("/", "/index.html"):
            return self._send(200, open(os.path.join(HERE, "static", "index.html"), "rb").read(), "text/html; charset=utf-8")
        if path == "/api/state":
            if not self._ok(): return self._send(401, {"error": "unauthorized"})
            return self._send(200, ENGINE.summary())
        self._send(404, {"error": "not found"})

    def do_POST(self):
        if urlparse(self.path).path != "/api/action": return self._send(404, {"error": "not found"})
        if not self._ok(): return self._send(401, {"error": "unauthorized"})
        try:
            body = json.loads(self.rfile.read(int(self.headers.get("Content-Length", 0))) or b"{}")
            a = body.get("action")
            if a == "start": ENGINE.set_enabled(True)
            elif a == "stop": ENGINE.set_enabled(False)
            elif a == "validate": ENGINE.validate()
            elif a == "settings": ENGINE.update_settings(body.get("settings", {}))
            elif a == "close": ENGINE.close(body["id"])
            elif a == "reset_paper": ENGINE.reset_paper()
            else: return self._send(400, {"error": "unknown action"})
            self._send(200, {"ok": True})
        except Exception as e:
            self._send(400, {"error": str(e)})

def main():
    global ENGINE
    demo = os.environ.get("DEMO") == "1"
    ENGINE = bot.Engine(bot.DemoMarket() if demo else bot.BinanceMarket())
    ENGINE.start_thread()
    port = int(os.environ.get("PORT", "8080"))
    print(f"\n  Dashboard: http://<this-machine-ip>:{port}\n  ACCESS TOKEN: {TOKEN}\n  (mode: {'DEMO' if demo else 'Binance'}, trading: {ENGINE.st['settings']['mode']}, auto_trade: {ENGINE.st['settings']['auto_trade']})\n", flush=True)
    ThreadingHTTPServer(("0.0.0.0", port), Handler).serve_forever()

if __name__ == "__main__": main()
