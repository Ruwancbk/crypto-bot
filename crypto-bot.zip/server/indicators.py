import numpy as np, pandas as pd

def ema(s, n): return s.ewm(span=n, adjust=False).mean()
def sma(s, n): return s.rolling(n).mean()

def rsi(s, n=14):
    d = s.diff(); up = d.clip(lower=0); dn = -d.clip(upper=0)
    ru = up.ewm(alpha=1/n, adjust=False).mean(); rd = dn.ewm(alpha=1/n, adjust=False).mean()
    return 100 - 100 / (1 + ru / rd.replace(0, np.nan))

def atr(df, n=14):
    pc = df["close"].shift()
    tr = pd.concat([df["high"]-df["low"], (df["high"]-pc).abs(), (df["low"]-pc).abs()], axis=1).max(axis=1)
    return tr.ewm(alpha=1/n, adjust=False).mean()

def macd(s, f=12, sl=26, sg=9):
    m = ema(s, f) - ema(s, sl); sig = ema(m, sg); return m, sig, m - sig

def bollinger(s, n=20, k=2.0):
    m = sma(s, n); sd = s.rolling(n).std(); return m, m + k*sd, m - k*sd

def stoch(df, n=14, d=3):
    ll = df["low"].rolling(n).min(); hh = df["high"].rolling(n).max()
    k = 100 * (df["close"] - ll) / (hh - ll).replace(0, np.nan)
    return k, k.rolling(d).mean()

def adx(df, n=14):
    up = df["high"].diff(); dn = -df["low"].diff()
    pdm = pd.Series(np.where((up > dn) & (up > 0), up, 0.0), index=df.index)
    mdm = pd.Series(np.where((dn > up) & (dn > 0), dn, 0.0), index=df.index)
    a = atr(df, n)
    pdi = 100 * pdm.ewm(alpha=1/n, adjust=False).mean() / a
    mdi = 100 * mdm.ewm(alpha=1/n, adjust=False).mean() / a
    dx = 100 * (pdi - mdi).abs() / (pdi + mdi).replace(0, np.nan)
    return dx.ewm(alpha=1/n, adjust=False).mean(), pdi, mdi

def supertrend(df, n=10, mult=3.0):
    a = atr(df, n).values; hl2 = ((df["high"] + df["low"]) / 2).values; c = df["close"].values
    ub = hl2 + mult*a; lb = hl2 - mult*a
    fu = ub.copy(); fl = lb.copy(); d = np.ones(len(df))
    for i in range(1, len(df)):
        fu[i] = ub[i] if (ub[i] < fu[i-1] or c[i-1] > fu[i-1]) else fu[i-1]
        fl[i] = lb[i] if (lb[i] > fl[i-1] or c[i-1] < fl[i-1]) else fl[i-1]
        if d[i-1] == 1 and c[i] < fl[i]: d[i] = -1
        elif d[i-1] == -1 and c[i] > fu[i]: d[i] = 1
        else: d[i] = d[i-1]
    return pd.Series(d, index=df.index)

def rolling_vwap(df, n=96):
    tp = (df["high"] + df["low"] + df["close"]) / 3
    return (tp * df["volume"]).rolling(n).sum() / df["volume"].rolling(n).sum()
